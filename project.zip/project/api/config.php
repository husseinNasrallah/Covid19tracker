<?php

return [
	'host' => 'localhost',
	'username' => 'root',
	'password' => '',
	'port' => '3306',
	'db' => 'coronatracking'
];